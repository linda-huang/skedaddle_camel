let net_ids = ["ae347"; "ddt45"; "sh837"; "tl676"]

let hours_worked = [25; 25; 25; 25]