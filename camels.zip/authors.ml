let net_ids = ["ae347"; "ddt45"; "sh837"; "tl676"]

let hours_worked = [6 (* absolutely too damn long fiddling with graphics*);
                    1; 1; 1]